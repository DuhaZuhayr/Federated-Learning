import { NetworkFeatures } from "./types";

export const PROTOCOL_TYPES = ['tcp', 'udp', 'icmp'];

export const SERVICES = [
  'http', 'smtp', 'ftp', 'domain_u', 'auth', 'finger', 'telnet', 'eco_i',
  'ftp_data', 'other', 'private', 'ecr_i', 'time', 'whois', 'domain', 'ssh'
];

export const FLAGS = [
  'SF', 'S0', 'REJ', 'RSTR', 'RSTO', 'S1', 'RSTOS0', 'S2', 'S3', 'OTH', 'SH'
];

export const DEFAULT_VALUES: NetworkFeatures = {
  duration: 0,
  protocol_type: 'tcp',
  service: 'http',
  flag: 'SF',
  src_bytes: 0,
  dst_bytes: 0,
  land: 0,
  wrong_fragment: 0,
  urgent: 0,
  hot: 0,
  num_failed_logins: 0,
  logged_in: 0,
  num_compromised: 0,
  root_shell: 0,
  su_attempted: 0,
  num_root: 0,
  num_file_creations: 0,
  num_shells: 0,
  num_access_files: 0,
  num_outbound_cmds: 0,
  is_host_login: 0,
  is_guest_login: 0,
  count: 0,
  srv_count: 0,
  serror_rate: 0.0,
  srv_serror_rate: 0.0,
  rerror_rate: 0.0,
  srv_rerror_rate: 0.0,
  same_srv_rate: 0.0,
  diff_srv_rate: 0.0,
  srv_diff_host_rate: 0.0,
  dst_host_count: 0,
  dst_host_srv_count: 0,
  dst_host_same_srv_rate: 0.0,
  dst_host_diff_srv_rate: 0.0,
  dst_host_same_src_port_rate: 0.0,
  dst_host_srv_diff_host_rate: 0.0,
  dst_host_serror_rate: 0.0,
  dst_host_srv_serror_rate: 0.0,
  dst_host_rerror_rate: 0.0,
  dst_host_srv_rerror_rate: 0.0,
};

// A preset for a suspicious activity to help user testing
export const SUSPICIOUS_PRESET: NetworkFeatures = {
  ...DEFAULT_VALUES,
  duration: 0,
  protocol_type: 'tcp',
  service: 'private',
  flag: 'S0',
  src_bytes: 0,
  dst_bytes: 0,
  count: 123,
  srv_count: 6,
  serror_rate: 1.0,
  srv_serror_rate: 1.0,
  dst_host_count: 255,
  dst_host_srv_count: 6,
  dst_host_same_srv_rate: 0.02,
  dst_host_serror_rate: 1.0,
};

export const FEATURE_DESCRIPTIONS: Record<string, string> = {
  duration: "Length (number of seconds) of the connection",
  protocol_type: "Type of the protocol, e.g. tcp, udp, etc.",
  service: "Network service on the destination, e.g., http, telnet",
  flag: "Normal or error status of the connection",
  src_bytes: "Number of data bytes from source to destination",
  dst_bytes: "Number of data bytes from destination to source",
  land: "1 if connection is from/to the same host/port; 0 otherwise",
  wrong_fragment: "Number of 'wrong' fragments",
  urgent: "Number of urgent packets",
  hot: "Number of 'hot' indicators",
  num_failed_logins: "Number of failed login attempts",
  logged_in: "1 if successfully logged in; 0 otherwise",
  num_compromised: "Number of compromised conditions",
  root_shell: "1 if root shell is obtained; 0 otherwise",
  su_attempted: "1 if 'su root' command attempted; 0 otherwise",
  num_root: "Number of 'root' accesses",
  num_file_creations: "Number of file creation operations",
  num_shells: "Number of shell prompts",
  